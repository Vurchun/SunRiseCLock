#include "stm32f10x.h"
//----------------------------------------------------------
#define LED1_ON() SET_BIT(GPIOA->ODR,GPIO_ODR_ODR2)
#define LED1_OFF() CLEAR_BIT(GPIOA->ODR,GPIO_ODR_ODR2)
#define LED2_ON() SET_BIT(GPIOA->ODR,GPIO_ODR_ODR3)
#define LED2_OFF() CLEAR_BIT(GPIOA->ODR,GPIO_ODR_ODR3)
#define LED3_ON() SET_BIT(GPIOA->ODR,GPIO_ODR_ODR4)
#define LED3_OFF() CLEAR_BIT(GPIOA->ODR,GPIO_ODR_ODR4)
#define LED4_ON() SET_BIT(GPIOA->ODR,GPIO_ODR_ODR5)
#define LED4_OFF() CLEAR_BIT(GPIOA->ODR,GPIO_ODR_ODR5)
#define LED5_ON() SET_BIT(GPIOA->ODR,GPIO_ODR_ODR6)
#define LED5_OFF() CLEAR_BIT(GPIOA->ODR,GPIO_ODR_ODR6)
#define LED6_ON() SET_BIT(GPIOA->ODR,GPIO_ODR_ODR7)
#define LED6_OFF() CLEAR_BIT(GPIOA->ODR,GPIO_ODR_ODR7)
#define LED7_ON() SET_BIT(GPIOB->ODR,GPIO_ODR_ODR0)
#define LED7_OFF() CLEAR_BIT(GPIOB->ODR,GPIO_ODR_ODR0)
#define LED8_ON() SET_BIT(GPIOB->ODR,GPIO_ODR_ODR1)
#define LED8_OFF() CLEAR_BIT(GPIOB->ODR,GPIO_ODR_ODR1)
#define LED9_ON() SET_BIT(GPIOB->ODR,GPIO_ODR_ODR10)
#define LED9_OFF() CLEAR_BIT(GPIOB->ODR,GPIO_ODR_ODR10)
#define LED10_ON() SET_BIT(GPIOB->ODR,GPIO_ODR_ODR11)
#define LED10_OFF() CLEAR_BIT(GPIOB->ODR,GPIO_ODR_ODR11)
//----------------------------------------------------------
#define SYSCLOCK 72000000U
//----------------------------------------------------------
#define TIM_EnableIT_UPDATE(TIMx) SET_BIT(TIMx->DIER, TIM_DIER_UIE)
#define TIM_EnableCounter(TIMx) SET_BIT(TIMx->CR1, TIM_CR1_CEN)
#define TIM_DisableCounter(TIMx) CLEAR_BIT(TIMx->CR1, TIM_CR1_CEN)
//----------------------------------------------------------
__IO uint32_t tmpreg;
__IO uint32_t SysTick_CNT = 0;
__IO uint8_t tim2_count = 0;
__IO uint8_t but1_count = 0;
__IO uint8_t but1_lock = 0;
__IO uint8_t led_count = 0;
//----------------------------------------------------------
__forceinline void delay(__IO uint32_t tck)
{
  while(tck)
  {
    tck--;
  }  
}
//----------------------------------------------------------
void delay_ms(uint32_t ms)
{
  MODIFY_REG(SysTick->VAL,SysTick_VAL_CURRENT_Msk,SYSCLOCK / 1000 - 1);
  SysTick_CNT = ms;
  while(SysTick_CNT) {}
}
//-----------------------------------------------------------
void RCC_DeInit(void)
{
  SET_BIT(RCC->CR, RCC_CR_HSION);
  while(READ_BIT(RCC->CR, RCC_CR_HSIRDY == RESET)) {}
  MODIFY_REG(RCC->CR, RCC_CR_HSITRIM, 0x80U);
  CLEAR_REG(RCC->CFGR);
  while (READ_BIT(RCC->CFGR, RCC_CFGR_SWS) != RESET) {}
  CLEAR_BIT(RCC->CR, RCC_CR_PLLON);
  while (READ_BIT(RCC->CR, RCC_CR_PLLRDY) != RESET) {}
  CLEAR_BIT(RCC->CR, RCC_CR_HSEON | RCC_CR_CSSON);
  while (READ_BIT(RCC->CR, RCC_CR_HSERDY) != RESET) {}
  CLEAR_BIT(RCC->CR, RCC_CR_HSEBYP);
  //Reset all CSR flags
  SET_BIT(RCC->CSR, RCC_CSR_RMVF);
}
//----------------------------------------------------------
void SetSysClockTo72(void)
{
  SET_BIT(RCC->CR, RCC_CR_HSEON);
  while(READ_BIT(RCC->CR, RCC_CR_HSERDY == RESET)) {}
  //Enable the Prefetch Buffer
  CLEAR_BIT(FLASH->ACR, FLASH_ACR_PRFTBE);
  SET_BIT(FLASH->ACR, FLASH_ACR_PRFTBE);
  MODIFY_REG(FLASH->ACR, FLASH_ACR_LATENCY, FLASH_ACR_LATENCY_2);
  MODIFY_REG(RCC->CFGR, RCC_CFGR_HPRE, RCC_CFGR_HPRE_DIV1);
  MODIFY_REG(RCC->CFGR, RCC_CFGR_PPRE2, RCC_CFGR_PPRE2_DIV1);
  MODIFY_REG(RCC->CFGR, RCC_CFGR_PPRE1, RCC_CFGR_PPRE1_DIV2);
  MODIFY_REG(RCC->CFGR, RCC_CFGR_PLLSRC | RCC_CFGR_PLLXTPRE | RCC_CFGR_PLLMULL,
             RCC_CFGR_PLLSRC | RCC_CFGR_PLLMULL9);
  SET_BIT(RCC->CR, RCC_CR_PLLON);
  while(READ_BIT(RCC->CR, RCC_CR_PLLRDY) != (RCC_CR_PLLRDY)) {}
  MODIFY_REG(RCC->CFGR, RCC_CFGR_SW, RCC_CFGR_SW_PLL);
  while(READ_BIT(RCC->CFGR, RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL) {}
}
//----------------------------------------------------------
void SysTick_Init(void)
{
  MODIFY_REG(SysTick->LOAD,SysTick_LOAD_RELOAD_Msk,SYSCLOCK / 1000 - 1);
  CLEAR_BIT(SysTick->VAL, SysTick_VAL_CURRENT_Msk);
  SET_BIT(SysTick->CTRL, SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_TICKINT_Msk);
}
//----------------------------------------------------------
static void TIM2_Init(void)
{
  SET_BIT(RCC->APB1ENR, RCC_APB1ENR_TIM2EN);
  NVIC_EnableIRQ(TIM2_IRQn);
  WRITE_REG(TIM2->PSC, 3599);
  WRITE_REG(TIM2->ARR, 50);
}
//----------------------------------------------------------
uint8_t IsBut01On(void)
{
  uint8_t res;
  if(!READ_BIT(GPIOA->IDR, GPIO_IDR_IDR1)) TIM_EnableCounter(TIM2);
  else return 0;
  while (tim2_count<20) {}
  TIM_DisableCounter(TIM2);
  if(but1_count>10) {res=1; but1_lock=1;}
  else res=0;
  tim2_count=0;
  but1_count=0;
  return res;  
}
//-----------------------------------------------------------
int main(void)
{
  RCC_DeInit();
  SET_BIT(RCC->APB2ENR, RCC_APB2ENR_AFIOEN);
  //Delay after an RCC peripheral clock enabling
  tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_AFIOEN);
  //NOJTAG: JTAG-DP Disabled and SW-DP Enabled 
  CLEAR_BIT(AFIO->MAPR,AFIO_MAPR_SWJ_CFG);
  SET_BIT(AFIO->MAPR, AFIO_MAPR_SWJ_CFG_JTAGDISABLE);
  SetSysClockTo72();
  SysTick_Init();
  SET_BIT(RCC->APB2ENR, RCC_APB2ENR_IOPAEN |RCC_APB2ENR_IOPBEN);
  TIM2_Init();
  //Delay after an RCC peripheral clock enabling
  tmpreg = READ_BIT(RCC->APB2ENR, RCC_APB2ENR_IOPAEN |RCC_APB2ENR_IOPBEN);
  MODIFY_REG(GPIOA->CRL, GPIO_CRL_CNF7 | GPIO_CRL_CNF6 | GPIO_CRL_CNF5 |\
             GPIO_CRL_CNF4 | GPIO_CRL_CNF3 | GPIO_CRL_CNF2 | GPIO_CRL_CNF1_0 |\
                       GPIO_CRL_MODE1,\
             GPIO_CRL_CNF1_1 | GPIO_CRL_MODE7_0 | GPIO_CRL_MODE6_0 | GPIO_CRL_MODE5_0 |\
             GPIO_CRL_MODE4_0 | GPIO_CRL_MODE3_0 | GPIO_CRL_MODE2_0);
  MODIFY_REG(GPIOB->CRH, GPIO_CRH_CNF11 | GPIO_CRH_CNF10,\
             GPIO_CRH_MODE11_0 | GPIO_CRH_MODE10_0);
  MODIFY_REG(GPIOB->CRL, GPIO_CRL_CNF1 | GPIO_CRL_CNF0,\
             GPIO_CRL_MODE1_0 | GPIO_CRL_MODE0_0);
  SET_BIT(GPIOA->ODR,GPIO_ODR_ODR1);
  TIM_EnableIT_UPDATE(TIM2);
  while(1)
	{
    if(!but1_lock)
    {
      if(IsBut01On())
      {
        switch(led_count)
        {
          case 0: LED10_OFF(); LED1_ON(); break;
          case 1: LED1_OFF();  LED2_ON(); break;
          case 2: LED2_OFF();  LED3_ON(); break;
          case 3: LED3_OFF();  LED4_ON(); break;
          case 4: LED4_OFF();  LED5_ON(); break;
          case 5: LED5_OFF();  LED6_ON(); break;
          case 6: LED6_OFF();  LED7_ON(); break;
          case 7: LED7_OFF();  LED8_ON(); break;
          case 8: LED8_OFF();  LED9_ON(); break;
          case 9: LED9_OFF(); LED10_ON(); break;
        }
      }
    }
    else
    {
      if(READ_BIT(GPIOA->IDR, GPIO_IDR_IDR1))
      {
        led_count++;
        if(led_count>9) led_count=0;
        but1_lock=0;
      }
    }
  }
}
//----------------------------------------------------------
void SysTick_Handler(void)
{
  if(SysTick_CNT > 0)  SysTick_CNT--;
}
//----------------------------------------------------------
void TIM2_IRQHandler(void)
{
  if(READ_BIT(TIM2->SR, TIM_SR_UIF))
  {
    CLEAR_BIT(TIM2->SR, TIM_SR_UIF);
    if(!READ_BIT(GPIOA->IDR, GPIO_IDR_IDR1)) but1_count++;
    tim2_count++;
  }
}
//----------------------------------------------------------
