#ifndef LED_H_
#define LED_H_
//--------------------------------------
#include "stm32f10x.h"
//--------------------------------------
void segchar (uint8_t seg);
void ledprint(uint16_t number);
//--------------------------------------
#endif /* LED_H_ */
